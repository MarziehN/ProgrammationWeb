<?php include 'entete.html';?>
<section>
<div class="container" style="margin-top:30px">
  <div class="row">
    <div class="col-sm-4">
      <p> HTML CSS Bootstrap PHP et PDO...</p>
    </div>
    <div class="col-sm-8">
    <p>   contenu...</p>
    </div>
   </div>
</div>
</section>
<?php include 'pieddepage.html';?>
</body>
</html>


